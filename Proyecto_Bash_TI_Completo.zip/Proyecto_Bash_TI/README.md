# Proyecto: Automatización de tareas administrativas en Linux con Bash

## 1. Descripción

Este proyecto resuelve tareas repetitivas del área de TI mediante scripts Bash modulares, seguros y reutilizables. Incluye:

1. **Reporte del entorno Linux:** usuario, sistema operativo, kernel, memoria, disco, fecha, red y validaciones de dependencias.
2. **Gestión de archivos y permisos:** creación de directorios y archivos, copia, cambio de permisos, eliminación por antigüedad y limpieza de temporales.
3. **Automatización externa:** generación e instalación controlada de una tarea `cron`, reporte estadístico con `awk` y reemplazo de texto con `sed`.
4. **Pruebas automáticas:** escenarios válidos e inválidos con verificación de resultados.

## 2. Integrantes y repositorio

- Integrante 1: ______________________________
- Integrante 2: ______________________________
- Repositorio GitHub: _________________________

## 3. Requisitos

- Ubuntu o Debian, o una distribución Linux equivalente.
- Bash 4.4 o superior.
- Herramientas estándar: `awk`, `sed`, `grep`, `find`, `df`, `chmod`, `cp`, `stat`, `crontab`.
- No se requieren privilegios de administrador para las funciones principales.

## 4. Estructura del proyecto

```text
Proyecto_Bash_TI/
├── scripts/
│   ├── entorno_sistema.sh
│   ├── gestor_archivos.sh
│   ├── automatizacion_basica.sh
│   └── menu_principal.sh
├── lib/utilidades.sh
├── config/configuracion.conf
├── datos/ejemplo_entrada.txt
├── cron/ejemplo_crontab.txt
├── pruebas/ejecutar_pruebas.sh
├── documentacion/
├── reportes/
├── logs/
└── README.md
```

## 5. Preparación

```bash
cd Proyecto_Bash_TI
chmod +x scripts/*.sh pruebas/*.sh lib/*.sh
```

Validación sintáctica:

```bash
for archivo in scripts/*.sh lib/*.sh pruebas/*.sh; do
  bash -n "$archivo" || exit 1
done
```

## 6. Uso de los scripts

### 6.1. Reporte del entorno

```bash
./scripts/entorno_sistema.sh
./scripts/entorno_sistema.sh --salida reportes/entorno.txt
```

**Salida:** reporte legible con información del usuario, sistema operativo, kernel, arquitectura, memoria, disco y dependencias.

### 6.2. Gestión de archivos

Crear directorio:

```bash
./scripts/gestor_archivos.sh crear-directorio /tmp/demo_ti 750
```

Crear archivo:

```bash
./scripts/gestor_archivos.sh crear-archivo /tmp/demo_ti/nota.txt "Prueba del proyecto"
```

Copiar archivo:

```bash
./scripts/gestor_archivos.sh copiar /tmp/demo_ti/nota.txt /tmp/demo_ti/copia.txt
```

Cambiar permisos:

```bash
./scripts/gestor_archivos.sh permisos /tmp/demo_ti/copia.txt 600
```

Simular eliminación por antigüedad:

```bash
./scripts/gestor_archivos.sh --dry-run eliminar-antiguos /tmp/demo_ti 7 "*.log"
```

Ejecutar eliminación real sin confirmación interactiva:

```bash
./scripts/gestor_archivos.sh --force eliminar-antiguos /tmp/demo_ti 7 "*.log"
```

Abrir menú interactivo:

```bash
./scripts/gestor_archivos.sh menu
```

### 6.3. Reporte con AWK

```bash
./scripts/automatizacion_basica.sh reporte-awk \
  datos/ejemplo_entrada.txt reportes/estadisticas.txt
```

El reporte presenta líneas, líneas vacías, palabras, caracteres, promedio de palabras por línea y frecuencia de términos.

### 6.4. Reemplazo con SED

```bash
cp datos/ejemplo_entrada.txt /tmp/datos_demo.txt
./scripts/automatizacion_basica.sh reemplazar-sed \
  /tmp/datos_demo.txt error INCIDENCIA
```

El script valida el archivo, cuenta coincidencias, crea `/tmp/datos_demo.txt.bak` y realiza el reemplazo.

### 6.5. Programación con CRON

Generar una tarea diaria a las 02:30:

```bash
mkdir -p /tmp/temporales
./scripts/automatizacion_basica.sh cron-generar \
  ./scripts/gestor_archivos.sh /tmp/temporales 7 02:30
```

Revisar el archivo generado:

```bash
cat cron/tarea_limpieza.cron
```

Instalar la tarea en el crontab del usuario:

```bash
./scripts/automatizacion_basica.sh cron-instalar cron/tarea_limpieza.cron
```

Mostrarla o retirarla:

```bash
./scripts/automatizacion_basica.sh cron-mostrar
./scripts/automatizacion_basica.sh cron-retirar
```

> La instalación es idempotente: reemplaza únicamente el bloque identificado por las marcas del proyecto y conserva las demás tareas del usuario.

### 6.6. Menú integrado

```bash
./scripts/menu_principal.sh
```

## 7. Pruebas y validaciones

```bash
./pruebas/ejecutar_pruebas.sh
cat pruebas/resultados_pruebas.txt
```

La suite comprueba:

- Sintaxis de todos los scripts.
- Generación del reporte de entorno.
- Creación, copia y permisos.
- Rechazo de permisos inválidos.
- Simulación y eliminación selectiva por fecha.
- Reporte con `awk`.
- Reemplazo y respaldo con `sed`.
- Generación correcta de la expresión `cron`.

## 8. Flujo de ejecución

```text
Usuario / cron
      |
      v
Validación de parámetros
      |
      v
Selección de operación con case
      |
      v
Funciones reutilizables
      |
      v
Comandos Linux (df, find, chmod, awk, sed, cron)
      |
      v
Salida estructurada + archivo de reporte + log
```

## 9. Buenas prácticas implementadas

- `set -Eeuo pipefail` para detectar errores tempranamente.
- Variables siempre entre comillas.
- `--` antes de rutas en comandos sensibles.
- Funciones pequeñas y reutilizables.
- Validación de rutas críticas, modos octales, fechas y horarios.
- Modo `--dry-run` antes de borrar.
- Copias de seguridad antes de modificar con `sed`.
- Logs con fecha, nivel y descripción.
- Mensajes de error enviados a `stderr`.
- Instalación de `cron` limitada al bloque del proyecto.
- Código comentado y ayuda integrada en cada script.

## 10. Limitaciones y mejoras

**Limitaciones actuales:**

- La fecha de eliminación se basa en la última modificación (`mtime`).
- La instalación de cron depende de que el servicio `cron` esté disponible.
- El reporte de palabras usa tokenización simple; no realiza análisis lingüístico avanzado.

**Mejoras propuestas:**

- Archivo de configuración cargado automáticamente.
- Rotación de logs.
- Notificación por correo cuando una tarea falle.
- Pruebas unitarias con Bats.
- Pipeline de integración continua en GitHub Actions.

## 11. Correspondencia con la rúbrica

| Criterio | Evidencia para nivel sobresaliente |
|---|---|
| Script de entorno | Más de cuatro parámetros, validación de comandos, salida estructurada, permisos y comentarios. |
| Gestión de archivos | Cuatro acciones principales, validaciones, errores claros, `dry-run`, protección de rutas críticas y logs. |
| Herramientas externas | Uso funcional y documentado de `cron`, `awk` y `sed`, con respaldo y verificación. |
| Documentación técnica | README, informe PDF, ejemplos, capturas, pruebas, limitaciones y mejoras. |
| Buenas prácticas | Modularidad, funciones, `if`, `case`, `for`, `while`, redirección, control de errores y mantenimiento. |

## 12. Resultado esperado

Al finalizar las pruebas, el archivo `pruebas/resultados_pruebas.txt` debe mostrar:

```text
RESULTADO FINAL: APROBADO
```
