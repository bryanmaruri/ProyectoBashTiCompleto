#!/usr/bin/env bash
# Muestra información esencial del entorno Linux y genera un reporte estructurado.

set -Eeuo pipefail
IFS=$'\n\t'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
# shellcheck source=../lib/utilidades.sh
source "$PROJECT_DIR/lib/utilidades.sh"

readonly VERSION="1.0.0"
SALIDA=""

uso() {
    cat <<USO
Uso: $(basename "$0") [opciones]

Opciones:
  -o, --salida ARCHIVO   Guarda el reporte en un archivo de texto.
  -h, --help             Muestra esta ayuda.
  -v, --version          Muestra la versión del script.

Ejemplo:
  $(basename "$0") --salida ../reportes/entorno.txt
USO
}

obtener_so() {
    if [[ -r /etc/os-release ]]; then
        # Se leen únicamente variables conocidas del archivo estándar del sistema.
        local nombre="Linux"
        local version="No disponible"
        nombre="$(awk -F= '$1=="NAME" {gsub(/\"/, "", $2); print $2}' /etc/os-release | head -n1)"
        version="$(awk -F= '$1=="VERSION" {sub(/^[^=]*=/, ""); gsub(/\"/, ""); print}' /etc/os-release | head -n1)"
        printf '%s %s\n' "${nombre:-Linux}" "${version:-No disponible}"
    else
        uname -s
    fi
}

obtener_memoria() {
    if comando_existe free; then
        free -h | awk '/^Mem:/ {printf "Total: %s | Usada: %s | Disponible: %s", $2, $3, $7}'
    else
        printf 'No disponible'
    fi
}

obtener_ip() {
    if comando_existe hostname; then
        hostname -I 2>/dev/null | awk '{print ($1=="" ? "No disponible" : $1)}'
    else
        printf 'No disponible'
    fi
}

generar_reporte() {
    requerir_comando awk
    requerir_comando df
    requerir_comando uname

    local usuario hostname_actual so kernel arquitectura fecha uptime_info shell_actual ip memoria
    local disco_total disco_usado disco_disp disco_pct

    usuario="${USER:-$(id -un)}"
    hostname_actual="$(hostname 2>/dev/null || printf 'No disponible')"
    so="$(obtener_so)"
    kernel="$(uname -r)"
    arquitectura="$(uname -m)"
    fecha="$(date '+%Y-%m-%d %H:%M:%S %Z')"
    uptime_info="$(uptime -p 2>/dev/null || uptime 2>/dev/null || printf 'No disponible')"
    shell_actual="${SHELL:-No disponible}"
    ip="$(obtener_ip)"
    memoria="$(obtener_memoria)"

    IFS=$'\t' read -r disco_total disco_usado disco_disp disco_pct < <(df -hP / | awk 'NR==2 {print $2 "\t" $3 "\t" $4 "\t" $5}')

    cat <<REPORTE
====================================================================
                 REPORTE DEL ENTORNO LINUX
====================================================================
Fecha y hora       : $fecha
Usuario actual     : $usuario
Nombre del equipo  : $hostname_actual
Dirección IP       : $ip
Sistema operativo  : $so
Versión del kernel : $kernel
Arquitectura       : $arquitectura
Shell configurado  : $shell_actual
Tiempo encendido   : $uptime_info
Directorio actual  : $PWD
--------------------------------------------------------------------
MEMORIA RAM
$memoria
--------------------------------------------------------------------
DISCO PRINCIPAL (/)
Total              : $disco_total
Usado              : $disco_usado
Disponible         : $disco_disp
Porcentaje usado   : $disco_pct
--------------------------------------------------------------------
VALIDACIONES
Lectura /etc/os-release : $([[ -r /etc/os-release ]] && echo "Correcta" || echo "No disponible")
Comando awk             : $(comando_existe awk && echo "Disponible" || echo "No disponible")
Comando sed             : $(comando_existe sed && echo "Disponible" || echo "No disponible")
Comando find            : $(comando_existe find && echo "Disponible" || echo "No disponible")
====================================================================
REPORTE
}

while (($# > 0)); do
    case "$1" in
        -o|--salida)
            (($# >= 2)) || morir "Falta indicar el archivo de salida."
            SALIDA="$2"
            shift 2
            ;;
        -h|--help)
            uso
            exit 0
            ;;
        -v|--version)
            printf '%s\n' "$VERSION"
            exit 0
            ;;
        *)
            uso >&2
            morir "Opción no reconocida: $1"
            ;;
    esac
done

if [[ -n "$SALIDA" ]]; then
    SALIDA="$(ruta_absoluta "$SALIDA")"
    mkdir -p "$(dirname "$SALIDA")"
    generar_reporte | tee "$SALIDA"
    ok "Reporte guardado correctamente en: $SALIDA"
else
    generar_reporte
fi
