#!/usr/bin/env bash
# Menú principal que integra los scripts del proyecto.

set -Eeuo pipefail
IFS=$'\n\t'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
source "$PROJECT_DIR/lib/utilidades.sh"

mostrar_menu() {
    cat <<MENU

============================================================
      SISTEMA DE AUTOMATIZACIÓN DE TAREAS EN BASH
============================================================
1) Mostrar información del entorno
2) Abrir gestor de archivos
3) Generar reporte AWK de un archivo
4) Reemplazar texto con sed
5) Generar tarea de limpieza para cron
6) Ejecutar pruebas automáticas
0) Salir
============================================================
MENU
}

while true; do
    mostrar_menu
    read -r -p "Seleccione una opción: " opcion

    case "$opcion" in
        1)
            "$SCRIPT_DIR/entorno_sistema.sh" --salida "$PROJECT_DIR/reportes/entorno_actual.txt"
            ;;
        2)
            "$SCRIPT_DIR/gestor_archivos.sh" menu
            ;;
        3)
            read -r -p "Archivo de entrada: " archivo
            read -r -p "Archivo de salida [automático]: " salida
            "$SCRIPT_DIR/automatizacion_basica.sh" reporte-awk "$archivo" "${salida:-$PROJECT_DIR/reportes/reporte_awk_manual.txt}"
            ;;
        4)
            read -r -p "Archivo: " archivo
            read -r -p "Texto a buscar: " buscar
            read -r -p "Texto de reemplazo: " reemplazo
            "$SCRIPT_DIR/automatizacion_basica.sh" reemplazar-sed "$archivo" "$buscar" "$reemplazo"
            ;;
        5)
            read -r -p "Directorio a limpiar: " directorio
            read -r -p "Días de antigüedad: " dias
            read -r -p "Hora de ejecución [02:00]: " hora
            "$SCRIPT_DIR/automatizacion_basica.sh" cron-generar \
                "$SCRIPT_DIR/gestor_archivos.sh" "$directorio" "$dias" "${hora:-02:00}"
            ;;
        6)
            "$PROJECT_DIR/pruebas/ejecutar_pruebas.sh"
            ;;
        0)
            ok "Programa finalizado."
            exit 0
            ;;
        *)
            error "Opción inválida."
            ;;
    esac
done
