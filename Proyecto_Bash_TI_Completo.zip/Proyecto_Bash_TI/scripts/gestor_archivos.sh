#!/usr/bin/env bash
# Gestiona archivos y directorios con validaciones, registro de eventos y modo seguro.

set -Eeuo pipefail
IFS=$'\n\t'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
# shellcheck source=../lib/utilidades.sh
source "$PROJECT_DIR/lib/utilidades.sh"

LOG_FILE="${LOG_FILE:-$PROJECT_DIR/logs/gestor_archivos.log}"
DRY_RUN=0
FORZAR=0

uso() {
    cat <<USO
Uso: $(basename "$0") [--dry-run] [--force] COMANDO [ARGUMENTOS]

Comandos:
  crear-directorio RUTA [MODO]          Crea un directorio. Modo por defecto: 750.
  crear-archivo RUTA [CONTENIDO]         Crea un archivo de texto. Modo por defecto: 640.
  copiar ORIGEN DESTINO                  Copia un archivo preservando sus atributos.
  permisos RUTA MODO                     Cambia permisos; MODO debe ser octal (ej. 640).
  eliminar-antiguos DIR DIAS [PATRON]    Elimina archivos con más de DIAS días.
  limpiar-temporales DIR DIAS            Elimina *.tmp, *.temp y *~ antiguos.
  menu                                   Abre un menú interactivo.
  ayuda                                  Muestra esta ayuda.

Opciones globales:
  --dry-run   Simula las eliminaciones sin modificar archivos.
  --force     Omite la confirmación en operaciones destructivas.

Ejemplos:
  $(basename "$0") crear-directorio /tmp/demo 750
  $(basename "$0") crear-archivo /tmp/demo/nota.txt "Prueba"
  $(basename "$0") copiar /tmp/demo/nota.txt /tmp/demo/copia.txt
  $(basename "$0") permisos /tmp/demo/copia.txt 600
  $(basename "$0") --dry-run eliminar-antiguos /tmp/demo 7 "*.log"
USO
}

crear_directorio() {
    local ruta="$1"
    local modo="${2:-750}"

    [[ -n "$ruta" ]] || morir "La ruta del directorio no puede estar vacía."
    es_modo_octal "$modo" || morir "Modo inválido: $modo. Use 3 o 4 dígitos octales."

    if [[ -d "$ruta" ]]; then
        advertencia "El directorio ya existe: $ruta"
        return 0
    fi

    mkdir -p -- "$ruta"
    chmod "$modo" -- "$ruta"
    ok "Directorio creado: $ruta (permisos $modo)"
}

crear_archivo() {
    local ruta="$1"
    local contenido="${2:-Archivo creado por gestor_archivos.sh}"

    [[ -n "$ruta" ]] || morir "La ruta del archivo no puede estar vacía."
    mkdir -p -- "$(dirname "$ruta")"

    if [[ -e "$ruta" ]]; then
        morir "El archivo ya existe y no será sobrescrito: $ruta"
    fi

    printf '%s\n' "$contenido" > "$ruta"
    chmod 640 -- "$ruta"
    ok "Archivo creado: $ruta (permisos 640)"
}

copiar_archivo() {
    local origen="$1"
    local destino="$2"

    [[ -f "$origen" ]] || morir "El archivo de origen no existe o no es regular: $origen"
    [[ "$origen" != "$destino" ]] || morir "El origen y el destino no pueden ser iguales."

    if [[ -d "$destino" ]]; then
        destino="$destino/$(basename "$origen")"
    else
        mkdir -p -- "$(dirname "$destino")"
    fi

    if [[ -e "$destino" && "$FORZAR" -ne 1 ]]; then
        morir "El destino ya existe. Use --force para sobrescribir: $destino"
    fi

    cp -p -- "$origen" "$destino"
    ok "Archivo copiado: $origen -> $destino"
}

cambiar_permisos() {
    local ruta="$1"
    local modo="$2"

    [[ -e "$ruta" ]] || morir "La ruta indicada no existe: $ruta"
    es_modo_octal "$modo" || morir "Modo inválido: $modo. Ejemplos válidos: 600, 640, 750."

    chmod "$modo" -- "$ruta"
    ok "Permisos actualizados: $ruta -> $modo"
}

eliminar_antiguos() {
    local directorio="$1"
    local dias="$2"
    local patron="${3:-*}"
    local encontrados=0
    local eliminados=0
    local archivo

    [[ -d "$directorio" ]] || morir "El directorio no existe: $directorio"
    es_entero_no_negativo "$dias" || morir "DIAS debe ser un entero no negativo."
    validar_ruta_peligrosa "$directorio"

    info "Buscando archivos en '$directorio' con patrón '$patron' y antigüedad mayor a $dias días."

    while IFS= read -r -d '' archivo; do
        ((encontrados+=1))
        printf '  - %s\n' "$archivo"
    done < <(find "$directorio" -type f -name "$patron" -mtime "+$dias" -print0 2>/dev/null)

    if ((encontrados == 0)); then
        advertencia "No se encontraron archivos que cumplan el criterio."
        return 0
    fi

    if ((DRY_RUN == 1)); then
        ok "Simulación finalizada: $encontrados archivo(s) serían eliminados."
        return 0
    fi

    if ((FORZAR != 1)); then
        confirmar "Se eliminarán $encontrados archivo(s). ¿Desea continuar?" || {
            advertencia "Operación cancelada por el usuario."
            return 0
        }
    fi

    while IFS= read -r -d '' archivo; do
        rm -f -- "$archivo"
        ((eliminados+=1))
        registrar_log OK "Archivo eliminado: $archivo"
    done < <(find "$directorio" -type f -name "$patron" -mtime "+$dias" -print0 2>/dev/null)

    ok "Limpieza completada: $eliminados archivo(s) eliminados."
}

limpiar_temporales() {
    local directorio="$1"
    local dias="$2"
    local total=0
    local patron

    for patron in '*.tmp' '*.temp' '*~'; do
        info "Procesando patrón temporal: $patron"
        eliminar_antiguos "$directorio" "$dias" "$patron"
        ((total+=1))
    done
    ok "Se procesaron $total patrones de archivos temporales."
}

menu_interactivo() {
    local opcion ruta modo origen destino contenido dias patron

    while true; do
        cat <<MENU

================ GESTOR DE ARCHIVOS ================
1) Crear directorio
2) Crear archivo
3) Copiar archivo
4) Cambiar permisos
5) Eliminar archivos antiguos
6) Limpiar archivos temporales
0) Salir
=====================================================
MENU
        read -r -p "Seleccione una opción: " opcion

        case "$opcion" in
            1)
                read -r -p "Ruta del directorio: " ruta
                read -r -p "Permisos [750]: " modo
                crear_directorio "$ruta" "${modo:-750}"
                ;;
            2)
                read -r -p "Ruta del archivo: " ruta
                read -r -p "Contenido inicial: " contenido
                crear_archivo "$ruta" "$contenido"
                ;;
            3)
                read -r -p "Archivo de origen: " origen
                read -r -p "Ruta de destino: " destino
                copiar_archivo "$origen" "$destino"
                ;;
            4)
                read -r -p "Ruta: " ruta
                read -r -p "Modo octal (ej. 640): " modo
                cambiar_permisos "$ruta" "$modo"
                ;;
            5)
                read -r -p "Directorio: " ruta
                read -r -p "Antigüedad en días: " dias
                read -r -p "Patrón [*]: " patron
                eliminar_antiguos "$ruta" "$dias" "${patron:-*}"
                ;;
            6)
                read -r -p "Directorio: " ruta
                read -r -p "Antigüedad en días: " dias
                limpiar_temporales "$ruta" "$dias"
                ;;
            0)
                ok "Fin del gestor de archivos."
                break
                ;;
            *)
                error "Opción inválida. Intente nuevamente."
                ;;
        esac
    done
}

while (($# > 0)); do
    case "$1" in
        --dry-run)
            DRY_RUN=1
            shift
            ;;
        --force)
            FORZAR=1
            shift
            ;;
        *)
            break
            ;;
    esac
done

COMANDO="${1:-ayuda}"
[[ $# -gt 0 ]] && shift || true

case "$COMANDO" in
    crear-directorio)
        (($# >= 1)) || morir "Falta RUTA."
        crear_directorio "$1" "${2:-750}"
        ;;
    crear-archivo)
        (($# >= 1)) || morir "Falta RUTA."
        crear_archivo "$1" "${2:-Archivo creado por gestor_archivos.sh}"
        ;;
    copiar)
        (($# >= 2)) || morir "Se requieren ORIGEN y DESTINO."
        copiar_archivo "$1" "$2"
        ;;
    permisos)
        (($# >= 2)) || morir "Se requieren RUTA y MODO."
        cambiar_permisos "$1" "$2"
        ;;
    eliminar-antiguos)
        (($# >= 2)) || morir "Se requieren DIRECTORIO y DIAS."
        eliminar_antiguos "$1" "$2" "${3:-*}"
        ;;
    limpiar-temporales)
        (($# >= 2)) || morir "Se requieren DIRECTORIO y DIAS."
        limpiar_temporales "$1" "$2"
        ;;
    menu)
        menu_interactivo
        ;;
    ayuda|-h|--help)
        uso
        ;;
    *)
        uso >&2
        morir "Comando no reconocido: $COMANDO"
        ;;
esac
