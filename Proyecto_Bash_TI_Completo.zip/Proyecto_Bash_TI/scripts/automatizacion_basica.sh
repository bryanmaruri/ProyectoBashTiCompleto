#!/usr/bin/env bash
# Automatiza tareas con cron, genera reportes con awk y reemplaza texto con sed.

set -Eeuo pipefail
IFS=$'\n\t'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
# shellcheck source=../lib/utilidades.sh
source "$PROJECT_DIR/lib/utilidades.sh"

LOG_FILE="${LOG_FILE:-$PROJECT_DIR/logs/automatizacion.log}"
readonly MARCA_INICIO="# INICIO PROYECTO_BASH_TI"
readonly MARCA_FIN="# FIN PROYECTO_BASH_TI"

uso() {
    cat <<USO
Uso: $(basename "$0") COMANDO [ARGUMENTOS]

Comandos:
  reporte-awk ARCHIVO [SALIDA]
      Genera estadísticas del archivo usando awk.

  reemplazar-sed ARCHIVO BUSCAR REEMPLAZO
      Sustituye texto con sed y crea una copia de seguridad .bak.

  cron-generar SCRIPT DIRECTORIO DIAS [HH:MM] [SALIDA]
      Genera una entrada cron para limpiar archivos antiguos.

  cron-instalar ARCHIVO_CRON
      Instala de forma idempotente la entrada cron generada.

  cron-retirar
      Elimina del crontab únicamente el bloque de este proyecto.

  cron-mostrar
      Muestra el bloque cron instalado por el proyecto.

Ejemplos:
  $(basename "$0") reporte-awk ../datos/ejemplo_entrada.txt ../reportes/estadisticas.txt
  $(basename "$0") reemplazar-sed archivo.txt error CORREGIDO
  $(basename "$0") cron-generar ../scripts/gestor_archivos.sh /tmp/temporales 7 02:30
USO
}

escapar_sed_patron() {
    printf '%s' "$1" | sed 's/[][\\.^$*\/]/\\&/g'
}

escapar_sed_reemplazo() {
    printf '%s' "$1" | sed 's/[&\\]/\\&/g; s#/#\\/#g'
}

generar_reporte_awk() {
    local archivo="$1"
    local salida="${2:-$PROJECT_DIR/reportes/reporte_awk_$(date '+%Y%m%d_%H%M%S').txt}"
    local temporal_frecuencias temporal_salida

    requerir_comando awk
    requerir_comando sort
    [[ -f "$archivo" ]] || morir "El archivo de entrada no existe: $archivo"
    [[ -r "$archivo" ]] || morir "No hay permisos de lectura sobre: $archivo"

    mkdir -p "$(dirname "$salida")"
    temporal_frecuencias="$(mktemp)"
    temporal_salida="$(mktemp)"

    awk -v frecuencias="$temporal_frecuencias" '
        BEGIN {
            lineas=0; vacias=0; palabras=0; caracteres=0;
        }
        {
            lineas++;
            caracteres += length($0);
            palabras += NF;
            if (NF == 0) vacias++;
            for (i=1; i<=NF; i++) {
                palabra=tolower($i);
                gsub(/[^[:alnum:]áéíóúüñ_-]/, "", palabra);
                if (palabra != "") frecuencia[palabra]++;
            }
        }
        END {
            printf "Líneas totales       : %d\n", lineas;
            printf "Líneas vacías        : %d\n", vacias;
            printf "Líneas con contenido : %d\n", lineas-vacias;
            printf "Palabras             : %d\n", palabras;
            printf "Caracteres (sin EOL) : %d\n", caracteres;
            printf "Promedio pal./línea  : %.2f\n", (lineas > 0 ? palabras/lineas : 0);
            for (p in frecuencia) {
                printf "%-25s %d\n", p, frecuencia[p] > frecuencias;
            }
        }
    ' "$archivo" > "$temporal_salida"

    {
        printf '%s\n' "============================================================"
        printf '%s\n' "             REPORTE GENERADO CON AWK"
        printf '%s\n' "============================================================"
        cat "$temporal_salida"
        printf '%s\n' "------------------------------------------------------------"
        printf '%s\n' "FRECUENCIA DE PALABRAS (ORDEN ALFABÉTICO)"
        sort -f "$temporal_frecuencias"
        printf '%s\n' "============================================================"
    } > "$salida.tmp"

    mv -f -- "$salida.tmp" "$salida"
    chmod 640 -- "$salida"

    cat "$salida"
    rm -f -- "$temporal_frecuencias" "$temporal_salida"
    ok "Reporte AWK creado en: $salida"
}

reemplazar_con_sed() {
    local archivo="$1"
    local buscar="$2"
    local reemplazo="$3"
    local patron_seguro reemplazo_seguro coincidencias

    requerir_comando sed
    requerir_comando grep
    [[ -f "$archivo" ]] || morir "El archivo no existe: $archivo"
    [[ -w "$archivo" ]] || morir "No hay permisos de escritura sobre: $archivo"
    [[ -n "$buscar" ]] || morir "El texto de búsqueda no puede estar vacío."

    coincidencias="$(grep -F -o -- "$buscar" "$archivo" 2>/dev/null | wc -l | tr -d ' ')"
    if [[ "$coincidencias" == "0" ]]; then
        advertencia "No se encontraron coincidencias para '$buscar'. El archivo no fue modificado."
        return 0
    fi

    patron_seguro="$(escapar_sed_patron "$buscar")"
    reemplazo_seguro="$(escapar_sed_reemplazo "$reemplazo")"

    cp -p -- "$archivo" "$archivo.bak"
    sed "s/$patron_seguro/$reemplazo_seguro/g" "$archivo.bak" > "$archivo.tmp"
    mv -f -- "$archivo.tmp" "$archivo"

    ok "Reemplazo completado: $coincidencias coincidencia(s)."
    info "Respaldo creado en: $archivo.bak"
}

validar_hora() {
    local hora="$1"
    [[ "$hora" =~ ^([01][0-9]|2[0-3]):([0-5][0-9])$ ]]
}

generar_cron() {
    local script="$1"
    local directorio="$2"
    local dias="$3"
    local hora="${4:-02:00}"
    local salida="${5:-$PROJECT_DIR/cron/tarea_limpieza.cron}"
    local minuto hora_num script_abs dir_abs

    [[ -f "$script" ]] || morir "No existe el script indicado: $script"
    [[ -x "$script" ]] || morir "El script no tiene permiso de ejecución: $script"
    [[ -d "$directorio" ]] || morir "El directorio objetivo no existe: $directorio"
    es_entero_no_negativo "$dias" || morir "DIAS debe ser un entero no negativo."
    validar_hora "$hora" || morir "Hora inválida: $hora. Use el formato HH:MM."
    validar_ruta_peligrosa "$directorio"

    script_abs="$(ruta_absoluta "$script")"
    dir_abs="$(ruta_absoluta "$directorio")"
    hora_num="${hora%%:*}"
    minuto="${hora##*:}"

    mkdir -p "$(dirname "$salida")"
    cat > "$salida" <<CRON
$MARCA_INICIO
# Limpieza diaria de archivos temporales con más de $dias día(s).
$minuto $hora_num * * * LOG_FILE="$PROJECT_DIR/logs/cron_limpieza.log" "$script_abs" --force limpiar-temporales "$dir_abs" "$dias" >> "$PROJECT_DIR/logs/cron_salida.log" 2>&1
$MARCA_FIN
CRON
    chmod 640 -- "$salida"

    cat "$salida"
    ok "Archivo cron generado en: $salida"
    advertencia "Revise la ruta y el horario antes de instalarlo con cron-instalar."
}

retirar_bloque_cron() {
    requerir_comando crontab
    local temporal
    temporal="$(mktemp)"

    (crontab -l 2>/dev/null || true) | awk \
        -v inicio="$MARCA_INICIO" -v fin="$MARCA_FIN" '
        $0 == inicio {omitir=1; next}
        $0 == fin {omitir=0; next}
        !omitir {print}
    ' > "$temporal"
    crontab "$temporal"
    rm -f -- "$temporal"
    ok "Bloque cron anterior retirado, si existía."
}

instalar_cron() {
    local archivo_cron="$1"
    local temporal

    requerir_comando crontab
    [[ -f "$archivo_cron" ]] || morir "No existe el archivo cron: $archivo_cron"
    grep -Fq "$MARCA_INICIO" "$archivo_cron" || morir "El archivo no contiene la marca de inicio esperada."
    grep -Fq "$MARCA_FIN" "$archivo_cron" || morir "El archivo no contiene la marca de fin esperada."

    temporal="$(mktemp)"

    (crontab -l 2>/dev/null || true) | awk \
        -v inicio="$MARCA_INICIO" -v fin="$MARCA_FIN" '
        $0 == inicio {omitir=1; next}
        $0 == fin {omitir=0; next}
        !omitir {print}
    ' > "$temporal"

    cat "$archivo_cron" >> "$temporal"
    crontab "$temporal"
    rm -f -- "$temporal"
    ok "Tarea cron instalada o actualizada correctamente."
}

mostrar_cron() {
    requerir_comando crontab
    (crontab -l 2>/dev/null || true) | awk \
        -v inicio="$MARCA_INICIO" -v fin="$MARCA_FIN" '
        $0 == inicio {mostrar=1}
        mostrar {print}
        $0 == fin {mostrar=0}
    '
}

COMANDO="${1:-ayuda}"
[[ $# -gt 0 ]] && shift || true

case "$COMANDO" in
    reporte-awk)
        (($# >= 1)) || morir "Falta ARCHIVO."
        generar_reporte_awk "$1" "${2:-}"
        ;;
    reemplazar-sed)
        (($# >= 3)) || morir "Se requieren ARCHIVO, BUSCAR y REEMPLAZO."
        reemplazar_con_sed "$1" "$2" "$3"
        ;;
    cron-generar)
        (($# >= 3)) || morir "Se requieren SCRIPT, DIRECTORIO y DIAS."
        generar_cron "$1" "$2" "$3" "${4:-02:00}" "${5:-$PROJECT_DIR/cron/tarea_limpieza.cron}"
        ;;
    cron-instalar)
        (($# >= 1)) || morir "Falta ARCHIVO_CRON."
        instalar_cron "$1"
        ;;
    cron-retirar)
        retirar_bloque_cron
        ;;
    cron-mostrar)
        mostrar_cron
        ;;
    ayuda|-h|--help)
        uso
        ;;
    *)
        uso >&2
        morir "Comando no reconocido: $COMANDO"
        ;;
esac
