#!/usr/bin/env bash
# Biblioteca de funciones comunes para los scripts del proyecto.

set -Eeuo pipefail
IFS=$'\n\t'

readonly COLOR_ROJO='\033[0;31m'
readonly COLOR_VERDE='\033[0;32m'
readonly COLOR_AMARILLO='\033[1;33m'
readonly COLOR_AZUL='\033[0;34m'
readonly COLOR_RESET='\033[0m'

usar_color() {
    [[ -t 1 && "${NO_COLOR:-0}" != "1" ]]
}

imprimir_mensaje() {
    local nivel="$1"
    shift
    local mensaje="$*"
    local color="$COLOR_RESET"

    case "$nivel" in
        INFO) color="$COLOR_AZUL" ;;
        OK) color="$COLOR_VERDE" ;;
        ADVERTENCIA) color="$COLOR_AMARILLO" ;;
        ERROR) color="$COLOR_ROJO" ;;
    esac

    if usar_color; then
        printf '%b[%s]%b %s\n' "$color" "$nivel" "$COLOR_RESET" "$mensaje"
    else
        printf '[%s] %s\n' "$nivel" "$mensaje"
    fi
}

registrar_log() {
    local nivel="$1"
    shift
    local mensaje="$*"
    local archivo_log="${LOG_FILE:-}"

    [[ -z "$archivo_log" ]] && return 0
    mkdir -p "$(dirname "$archivo_log")"
    printf '%s | %-11s | %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$nivel" "$mensaje" >> "$archivo_log"
}

info() {
    imprimir_mensaje INFO "$*"
    registrar_log INFO "$*"
}

ok() {
    imprimir_mensaje OK "$*"
    registrar_log OK "$*"
}

advertencia() {
    imprimir_mensaje ADVERTENCIA "$*"
    registrar_log ADVERTENCIA "$*"
}

error() {
    imprimir_mensaje ERROR "$*" >&2
    registrar_log ERROR "$*"
}

morir() {
    error "$*"
    exit 1
}

comando_existe() {
    command -v "$1" >/dev/null 2>&1
}

requerir_comando() {
    local comando="$1"
    comando_existe "$comando" || morir "No se encontró el comando requerido: $comando"
}

es_entero_no_negativo() {
    [[ "$1" =~ ^[0-9]+$ ]]
}

es_modo_octal() {
    [[ "$1" =~ ^[0-7]{3,4}$ ]]
}

ruta_absoluta() {
    local ruta="$1"
    if comando_existe realpath; then
        realpath -m -- "$ruta"
    else
        case "$ruta" in
            /*) printf '%s\n' "$ruta" ;;
            *) printf '%s/%s\n' "$PWD" "$ruta" ;;
        esac
    fi
}

validar_ruta_peligrosa() {
    local ruta
    ruta="$(ruta_absoluta "$1")"
    case "$ruta" in
        /|/bin|/boot|/dev|/etc|/home|/lib|/lib64|/proc|/root|/run|/sbin|/sys|/usr|/var)
            morir "Operación bloqueada sobre una ruta crítica del sistema: $ruta"
            ;;
    esac
}

confirmar() {
    local pregunta="$1"
    local respuesta
    read -r -p "$pregunta [s/N]: " respuesta
    [[ "$respuesta" =~ ^[sS]$ ]]
}
