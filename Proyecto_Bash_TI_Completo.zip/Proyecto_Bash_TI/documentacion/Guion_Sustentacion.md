# Guion de sustentación técnica (7 a 10 minutos)

## 1. Presentación del problema

“En el área de TI se realizaban manualmente tareas como revisar el uso de disco, organizar archivos, eliminar temporales y preparar reportes. Esto incrementaba el tiempo de atención y el riesgo de errores. La solución propuesta es un conjunto de scripts Bash modulares, documentados y validados.”

## 2. Arquitectura

“El proyecto tiene cuatro scripts ejecutables y una biblioteca común. `entorno_sistema.sh` recopila información; `gestor_archivos.sh` administra archivos; `automatizacion_basica.sh` integra cron, awk y sed; y `menu_principal.sh` ofrece una interfaz central. La biblioteca `utilidades.sh` concentra mensajes, logs y validaciones.”

## 3. Demostración del script de entorno

Comando:

```bash
./scripts/entorno_sistema.sh --salida reportes/entorno.txt
```

Explicar que se muestran usuario, SO, kernel, arquitectura, memoria, disco, red y estado de herramientas. Resaltar que la salida también se guarda con `tee`.

## 4. Demostración del gestor de archivos

```bash
./scripts/gestor_archivos.sh crear-directorio /tmp/demo_ti 750
./scripts/gestor_archivos.sh crear-archivo /tmp/demo_ti/nota.txt "Prueba"
./scripts/gestor_archivos.sh copiar /tmp/demo_ti/nota.txt /tmp/demo_ti/copia.txt
./scripts/gestor_archivos.sh permisos /tmp/demo_ti/copia.txt 600
```

Mostrar una simulación de limpieza:

```bash
./scripts/gestor_archivos.sh --dry-run eliminar-antiguos /tmp/demo_ti 7 "*.tmp"
```

Explicar las validaciones de ruta, permisos, existencia y confirmación.

## 5. Herramientas externas

### AWK

```bash
./scripts/automatizacion_basica.sh reporte-awk datos/ejemplo_entrada.txt reportes/estadisticas.txt
```

### SED

```bash
cp datos/ejemplo_entrada.txt /tmp/datos_demo.txt
./scripts/automatizacion_basica.sh reemplazar-sed /tmp/datos_demo.txt error INCIDENCIA
```

### CRON

```bash
mkdir -p /tmp/temporales
./scripts/automatizacion_basica.sh cron-generar ./scripts/gestor_archivos.sh /tmp/temporales 7 02:30
```

Explicar que el cron generado ejecuta la limpieza diariamente y redirige salida estándar y errores a logs.

## 6. Pruebas

```bash
./pruebas/ejecutar_pruebas.sh
```

Mencionar los escenarios válidos e inválidos, y mostrar `RESULTADO FINAL: APROBADO`.

## 7. Estructuras de control

- `if`: validaciones y comprobación de recursos.
- `case`: selección de comandos y opciones del menú.
- `for`: procesamiento de patrones temporales y scripts de prueba.
- `while`: menús y lectura segura de resultados de `find`.
- Funciones: reutilización y mantenimiento.

## 8. Limitaciones y mejoras

“Actualmente se usa `mtime` para determinar antigüedad y se depende del servicio cron. Como mejora se propone rotación de logs, alertas, configuración externa y pruebas con Bats y GitHub Actions.”

## 9. Cierre

“La solución reduce trabajo manual, protege frente a entradas inválidas, genera trazabilidad mediante reportes y logs, y cumple con los criterios de funcionalidad, documentación y buenas prácticas de la rúbrica.”
