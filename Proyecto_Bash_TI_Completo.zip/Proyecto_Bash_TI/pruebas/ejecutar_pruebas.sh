#!/usr/bin/env bash
# Suite de pruebas funcionales y de validación para los scripts del proyecto.

set -Eeuo pipefail
IFS=$'\n\t'

PRUEBAS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$PRUEBAS_DIR/.." && pwd)"
SCRIPT_DIR="$PROJECT_DIR/scripts"
SANDBOX="$PRUEBAS_DIR/sandbox"
RESULTADOS="$PRUEBAS_DIR/resultados_pruebas.txt"

export NO_COLOR=1
export LOG_FILE="$PRUEBAS_DIR/pruebas.log"

PASADAS=0
FALLIDAS=0

limpiar() {
    rm -rf "$SANDBOX"
    mkdir -p "$SANDBOX" "$PROJECT_DIR/reportes" "$PROJECT_DIR/cron"
    : > "$RESULTADOS"
    : > "$LOG_FILE"
}

registrar() {
    printf '%s\n' "$*" | tee -a "$RESULTADOS"
}

pasar() {
    ((PASADAS+=1))
    registrar "[PASÓ] $*"
}

fallar() {
    ((FALLIDAS+=1))
    registrar "[FALLÓ] $*"
}

probar_comando() {
    local nombre="$1"
    shift
    if "$@" >> "$RESULTADOS" 2>&1; then
        pasar "$nombre"
    else
        fallar "$nombre"
    fi
}

assert_archivo() {
    local archivo="$1"
    [[ -f "$archivo" ]]
}

assert_no_archivo() {
    local archivo="$1"
    [[ ! -e "$archivo" ]]
}

assert_contiene() {
    local archivo="$1"
    local texto="$2"
    grep -Fq -- "$texto" "$archivo"
}

limpiar
registrar "============================================================"
registrar "EJECUCIÓN DE PRUEBAS - $(date '+%Y-%m-%d %H:%M:%S')"
registrar "============================================================"

# 1. Validación sintáctica.
for script in "$SCRIPT_DIR"/*.sh "$PROJECT_DIR/lib"/*.sh; do
    probar_comando "Sintaxis Bash: $(basename "$script")" bash -n "$script"
done

# 2. Script de entorno.
ENTORNO_OUT="$SANDBOX/reporte_entorno.txt"
probar_comando "Generación de reporte del entorno" \
    "$SCRIPT_DIR/entorno_sistema.sh" --salida "$ENTORNO_OUT"
if assert_archivo "$ENTORNO_OUT" && assert_contiene "$ENTORNO_OUT" "Usuario actual"; then
    pasar "Contenido estructurado del reporte de entorno"
else
    fallar "Contenido estructurado del reporte de entorno"
fi

# 3. Gestión de archivos: crear, copiar y permisos.
DIR_DEMO="$SANDBOX/archivos"
ARCHIVO_ORIGINAL="$DIR_DEMO/original.txt"
ARCHIVO_COPIA="$DIR_DEMO/copia.txt"
probar_comando "Creación de directorio" \
    "$SCRIPT_DIR/gestor_archivos.sh" crear-directorio "$DIR_DEMO" 750
probar_comando "Creación de archivo" \
    "$SCRIPT_DIR/gestor_archivos.sh" crear-archivo "$ARCHIVO_ORIGINAL" "error controlado para prueba"
probar_comando "Copia de archivo" \
    "$SCRIPT_DIR/gestor_archivos.sh" copiar "$ARCHIVO_ORIGINAL" "$ARCHIVO_COPIA"
probar_comando "Cambio de permisos" \
    "$SCRIPT_DIR/gestor_archivos.sh" permisos "$ARCHIVO_COPIA" 600

if [[ "$(stat -c '%a' "$ARCHIVO_COPIA")" == "600" ]]; then
    pasar "Verificación real de permisos 600"
else
    fallar "Verificación real de permisos 600"
fi

# 4. Entrada inválida: el script debe rechazar permisos no octales.
if "$SCRIPT_DIR/gestor_archivos.sh" permisos "$ARCHIVO_COPIA" 999 >> "$RESULTADOS" 2>&1; then
    fallar "Rechazo de modo de permisos inválido"
else
    pasar "Rechazo de modo de permisos inválido"
fi

# 5. Eliminación por antigüedad, primero simulada y luego real.
ARCHIVO_ANTIGUO="$DIR_DEMO/antiguo.tmp"
ARCHIVO_NUEVO="$DIR_DEMO/nuevo.tmp"
printf 'antiguo\n' > "$ARCHIVO_ANTIGUO"
printf 'nuevo\n' > "$ARCHIVO_NUEVO"
touch -d '10 days ago' "$ARCHIVO_ANTIGUO"
probar_comando "Simulación de eliminación de archivos antiguos" \
    "$SCRIPT_DIR/gestor_archivos.sh" --dry-run eliminar-antiguos "$DIR_DEMO" 7 '*.tmp'
if assert_archivo "$ARCHIVO_ANTIGUO"; then
    pasar "Dry-run no modifica archivos"
else
    fallar "Dry-run no modifica archivos"
fi
probar_comando "Eliminación real de archivos antiguos" \
    "$SCRIPT_DIR/gestor_archivos.sh" --force eliminar-antiguos "$DIR_DEMO" 7 '*.tmp'
if assert_no_archivo "$ARCHIVO_ANTIGUO" && assert_archivo "$ARCHIVO_NUEVO"; then
    pasar "Eliminación selectiva por fecha"
else
    fallar "Eliminación selectiva por fecha"
fi

# 6. Reporte con AWK.
DATOS_PRUEBA="$SANDBOX/datos.txt"
cp "$PROJECT_DIR/datos/ejemplo_entrada.txt" "$DATOS_PRUEBA"
REPORTE_AWK="$SANDBOX/reporte_awk.txt"
probar_comando "Generación de reporte con AWK" \
    "$SCRIPT_DIR/automatizacion_basica.sh" reporte-awk "$DATOS_PRUEBA" "$REPORTE_AWK"
if assert_contiene "$REPORTE_AWK" "Palabras"; then
    pasar "Validación del contenido del reporte AWK"
else
    fallar "Validación del contenido del reporte AWK"
fi

# 7. Reemplazo con sed y respaldo.
probar_comando "Reemplazo de palabras con sed" \
    "$SCRIPT_DIR/automatizacion_basica.sh" reemplazar-sed "$DATOS_PRUEBA" "error" "INCIDENCIA"
if assert_contiene "$DATOS_PRUEBA" "INCIDENCIA" && assert_archivo "$DATOS_PRUEBA.bak"; then
    pasar "Reemplazo y creación de respaldo con sed"
else
    fallar "Reemplazo y creación de respaldo con sed"
fi

# 8. Generación de cron.
CRON_OUT="$SANDBOX/tarea.cron"
probar_comando "Generación de tarea cron" \
    "$SCRIPT_DIR/automatizacion_basica.sh" cron-generar \
    "$SCRIPT_DIR/gestor_archivos.sh" "$DIR_DEMO" 7 02:30 "$CRON_OUT"
if assert_contiene "$CRON_OUT" "30 02 * * *" && assert_contiene "$CRON_OUT" "limpiar-temporales"; then
    pasar "Validación de horario y comando cron"
else
    fallar "Validación de horario y comando cron"
fi

registrar "------------------------------------------------------------"
registrar "PRUEBAS PASADAS : $PASADAS"
registrar "PRUEBAS FALLIDAS: $FALLIDAS"
registrar "------------------------------------------------------------"

if ((FALLIDAS == 0)); then
    registrar "RESULTADO FINAL: APROBADO"
    exit 0
else
    registrar "RESULTADO FINAL: REQUIERE CORRECCIÓN"
    exit 1
fi
